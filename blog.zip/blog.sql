/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : blog

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2019-08-02 18:59:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(55) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', '77e2edcc9b40441200e31dc57dbb8829', null, null, null);
INSERT INTO `admin` VALUES ('2', 'sa', '788ef84d5a89a1ce91c310ec164f8d47', null, null, null);

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `atitle` varchar(50) DEFAULT NULL COMMENT '文章标题',
  `apic` varchar(255) DEFAULT NULL COMMENT '封面图',
  `aname` varchar(255) DEFAULT NULL COMMENT '文章发布人',
  `atext` text COMMENT '文章详情',
  `likes` int(11) DEFAULT '0' COMMENT '点赞数',
  `allpinglun` int(11) DEFAULT '0' COMMENT '评论数',
  `fenlei` varchar(255) DEFAULT NULL COMMENT '分类类别',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article
-- ----------------------------
INSERT INTO `article` VALUES ('1', '这是一条很长很长很长的标题', 'http://hh.cc/uploads/20190802\\8c5c7eee6d77c0e29efd372713109027.jpg', '测试1', '\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详\r\n\r\n', '4', '1', null, '1564712343', '1564717559', null);
INSERT INTO `article` VALUES ('5', '1', 'asdsa', '测试', '测试内容', '0', '0', '侧测试内容', '1564734040', '1564735713', '1564735713');
INSERT INTO `article` VALUES ('2', '这是一条很长很长很长的标题', 'http://hh.cc/uploads/20190802\\8c5c7eee6d77c0e29efd372713109027.jpg', '测试2', '\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详\r\n\r\n', '2', '2', '', '1564712343', '1564734849', null);
INSERT INTO `article` VALUES ('3', '这是一条很长很长很长的标题', 'http://hh.cc/uploads/20190802\\8c5c7eee6d77c0e29efd372713109027.jpg', '测试3', '\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详\r\n\r\n', '2', '2', '', '1564712343', '1564717544', null);
INSERT INTO `article` VALUES ('4', '这是一条很长很长很长的标题', 'http://hh.cc/uploads/20190802\\8c5c7eee6d77c0e29efd372713109027.jpg', '测试4', '<p>\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详情\r\n\r\n\r\n详<br></p><p><br></p>', '0', '6', '', '1564712343', '1564737035', null);

-- ----------------------------
-- Table structure for fenlei
-- ----------------------------
DROP TABLE IF EXISTS `fenlei`;
CREATE TABLE `fenlei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) DEFAULT NULL COMMENT '分类名称',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fenlei
-- ----------------------------
INSERT INTO `fenlei` VALUES ('1', '公益', null, null, null);
INSERT INTO `fenlei` VALUES ('2', '鸡汤', null, null, null);

-- ----------------------------
-- Table structure for like
-- ----------------------------
DROP TABLE IF EXISTS `like`;
CREATE TABLE `like` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) DEFAULT NULL COMMENT '文章id',
  `uid` int(11) DEFAULT NULL COMMENT '用户ID',
  `state` tinyint(3) DEFAULT NULL COMMENT '点赞状态 未点赞：0/已点赞：1',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of like
-- ----------------------------
INSERT INTO `like` VALUES ('1', '2', '52', '1', '1564734839', '1564734849', null);
INSERT INTO `like` VALUES ('2', '5', '52', '1', '1564735196', '1564736521', null);
INSERT INTO `like` VALUES ('3', '5', '52', '0', null, null, null);
INSERT INTO `like` VALUES ('4', '4', '52', '0', '1564736620', '1564736642', null);
INSERT INTO `like` VALUES ('5', '4', '1', '1', '1564736772', '1564736772', null);

-- ----------------------------
-- Table structure for pinglun
-- ----------------------------
DROP TABLE IF EXISTS `pinglun`;
CREATE TABLE `pinglun` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aid` int(11) DEFAULT NULL COMMENT '文章id',
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `ptext` text COMMENT '评论详情',
  `pname` varchar(255) DEFAULT NULL COMMENT '评论人',
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pinglun
-- ----------------------------
INSERT INTO `pinglun` VALUES ('1', '4', '1', '这是一条很有素质的评论', '测试', '1564736995', '1564736995', null);
INSERT INTO `pinglun` VALUES ('2', '4', '1', '这是一条很有素质的评论', '测试', '1564737035', '1564737035', null);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` int(32) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `update_time` int(11) DEFAULT NULL,
  `delete_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', null, '测试', null, null, null);
